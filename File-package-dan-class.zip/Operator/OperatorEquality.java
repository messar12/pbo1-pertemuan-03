package Operator;

public class OperatorEquality {
    public static void main(String[] args) {
        int i = 5;
        int j = 6;

        System.out.println(i==5);
        System.out.println(i==6);
        System.out.println(i==j);
        System.out.println(i>j);
        System.out.println(i<j);
        System.out.println(5>6);
        System.out.println(5<6);
        System.out.println(i!=5);
        System.out.println(j!=5);
    }
}
