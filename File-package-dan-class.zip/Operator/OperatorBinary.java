package Operator;

public class OperatorBinary {
    String Nama = "Ahmad Messar";
    int JumlahSks = 24;
    double Ipk = 3.89;

    public static void main(String[] args) {
        System.out.println(9+3);
        System.out.println(9-3);
        System.out.println(9*3);
        System.out.println(9/3);
        System.out.println(9%3);
        System.out.println(9%2);

    }

}
