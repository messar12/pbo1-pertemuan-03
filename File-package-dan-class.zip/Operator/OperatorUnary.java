package Operator;

import org.w3c.dom.ls.LSOutput;

public class OperatorUnary {
    public static void main(String[] args) {
        int i =0;
        i++;
        System.out.println(i);
        i++;
        System.out.println(i);
        i=i+1;
        System.out.println(i);
    }


}
