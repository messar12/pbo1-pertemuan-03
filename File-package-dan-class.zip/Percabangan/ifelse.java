package Percabangan;

public class ifelse {
    public static void main(String[] args) {
        int uang = 25000;
        int belanja= 50000;

        if (uang < belanja) {
            System.out.println("Uang Tidak Cukup");

        }else {
            System.out.println("uang Cukup");

        }
    }
}
