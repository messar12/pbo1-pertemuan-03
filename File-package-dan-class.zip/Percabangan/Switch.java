package Percabangan;

public class Switch {
    public static void main(String[] args) {
        int jalan = 3;
        switch (jalan){
            case 1:
                System.out.println("orang lapas");
                break;
            case 2:
                System.out.println("orang pacaran");
                break;
            case 3:
                System.out.println("Gue Ganteng");

        }
    }
}
